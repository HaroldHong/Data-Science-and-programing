

require(Rwordseg)

segmentCN("hello word!")













